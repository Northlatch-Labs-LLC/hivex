#!/usr/bin/env bash
#
# Open the operator dashboard, and close it again when you are done.
#
# The dashboard's backend listens on 127.0.0.1:3001 on the gateway droplet and is reachable from
# nowhere else — not from portal.weir.social, not from api.weir.social. That is deliberate: the
# operator's surface has no public door. This script is the door.
#
# It opens an SSH tunnel, waits until the far end actually answers, opens your browser at it, and
# then holds. Press Ctrl-C, or close this terminal window, and the tunnel is torn down with it.
#
#   ./dashboard.sh
#
# The tunnel carries nothing but your own SSH session. Nothing is exposed to the network: the local
# end is bound to 127.0.0.1, so another machine on your wifi cannot reach it either.

set -euo pipefail

HOST="${GATEWAY_HOST:-root@104.248.38.247}"
KEY="${GATEWAY_KEY:-$HOME/.config/protocolx/heron/ssh/heron-ssh}"
REMOTE_PORT=3001
LOCAL_PORT="${DASHBOARD_PORT:-3001}"

TUNNEL_PID=""

# Tear the tunnel down however this script ends: Ctrl-C, a closed terminal, or a failure below.
cleanup() {
  if [[ -n "$TUNNEL_PID" ]] && kill -0 "$TUNNEL_PID" 2>/dev/null; then
    kill "$TUNNEL_PID" 2>/dev/null || true
    wait "$TUNNEL_PID" 2>/dev/null || true
    echo ""
    echo "Tunnel closed. The dashboard is no longer reachable from this machine."
  fi
}
trap cleanup EXIT INT TERM

if [[ ! -f "$KEY" ]]; then
  echo "No SSH key at $KEY" >&2
  echo "Set GATEWAY_KEY to its path, or put it there." >&2
  exit 1
fi

# A port already in use is somebody else's service, and forwarding onto it would either fail or,
# worse, look like it worked while you read the wrong thing.
if lsof -ti tcp:"$LOCAL_PORT" >/dev/null 2>&1; then
  echo "Port $LOCAL_PORT is already in use on this machine." >&2
  echo "Close whatever holds it, or run: DASHBOARD_PORT=3002 $0" >&2
  exit 1
fi

echo "Opening a tunnel to the dashboard…"

# -N: no remote command, this is a tunnel and nothing else.
# 127.0.0.1 on the local side: reachable from this machine only, never from the network.
ssh -N \
  -o BatchMode=yes \
  -o ConnectTimeout=20 \
  -o ServerAliveInterval=30 \
  -o ExitOnForwardFailure=yes \
  -i "$KEY" \
  -L "127.0.0.1:${LOCAL_PORT}:127.0.0.1:${REMOTE_PORT}" \
  "$HOST" &
TUNNEL_PID=$!

# Wait for the far end to actually answer. A tunnel that is up is not the same as an application
# that is running, and opening a browser at a dead port teaches you nothing.
URL="http://localhost:${LOCAL_PORT}"
for _ in $(seq 1 20); do
  sleep 0.5
  if ! kill -0 "$TUNNEL_PID" 2>/dev/null; then
    echo "The tunnel closed before it was ready. Check the key and the host." >&2
    exit 1
  fi
  if curl -s -o /dev/null --max-time 2 "${URL}/api/auth/me"; then
    echo "Dashboard is up at ${URL}"
    if command -v open >/dev/null 2>&1; then open "$URL"; fi
    echo ""
    echo "Leave this window open while you work."
    echo "Press Ctrl-C, or close this window, to close the tunnel."
    wait "$TUNNEL_PID"
    exit 0
  fi
done

echo "The tunnel opened but the dashboard did not answer on port ${REMOTE_PORT}." >&2
echo "The container may be down. Check with:" >&2
echo "  ssh -i $KEY $HOST 'docker ps'" >&2
exit 1
