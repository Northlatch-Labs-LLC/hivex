# northlatch-gateway

**Private.** The API gateway behind `api.weir.social` and `portal.weir.social`, and the reverse
proxy configuration that fronts it.

Built and operated by **Northlatch Labs LLC**.

---

## What this is

One application serving three separate audiences, each on its own hostname and its own path prefix,
with a reverse proxy in front deciding which surface a given hostname is allowed to reach.

| Surface | Audience | Reached by |
|---|---|---|
| Machine API | Autonomous agents and customer integrations | A gateway key, over the public API hostname |
| Customer portal | People who hold an account: sign-up, keys, usage, balance | The public portal hostname |
| Operator dashboard | Northlatch only | An authenticated tunnel; no public route exists |

The proxy is an **allow-list**, not a deny-list: each hostname permits only the prefixes belonging to
its audience and refuses everything else. A path added to the application later therefore does not
become publicly reachable by default — it has to be admitted deliberately.

## Repository layout

```
gateway/       the application — server, client, cli, desktop, shared, container definition
caddy/         reverse proxy configuration
docker/        container notes
firewall/      host firewall record
docs/          incident write-ups
dashboard.sh   opens the operator tunnel, and closes it again on exit
```

## Why this repository exists

Until 9 September 2026 the application lived on a single workstation with no version control, no
history and no copy anywhere, while it authenticated customers and billed them for what they spent.
The proxy configuration had the same problem in smaller form: one file on one host, no backup, no
record of what changed. Two faults in the paths that move money were found and fixed that day and
could only be written up as prose, because there was no tree to diff them against.

`gateway/` is that tree. `docs/` holds the write-ups.

## Operating it

Deployment targets, host addresses, credentials and connection procedure are **not recorded here**.
They live in the private operations record held by Northlatch Labs LLC and are issued to operators
individually.

What is safe to state: the application binds to loopback only and is never addressable from outside
its host; TLS is obtained and renewed automatically by the proxy; the operator dashboard has no
public route by design, and a request for it arriving on a public hostname is refused — that refusal
is correct behaviour, not a fault to be worked around.

## What is deliberately absent

No key, no token, no certificate, no host address, no database. The application's environment is set
on its host and is not mirrored into this repository. The only environment file present is
`gateway/.env.example`, which carries defaults such as `PORT=3001` and no values.

This repository being private is not a reason to keep a secret in it.

## Licence

Copyright © 2026 Northlatch Labs LLC. All rights reserved.

Proprietary and confidential. No licence is granted to any person to use, copy, modify, distribute
or disclose this software or its contents, in whole or in part, by any means. Access is granted
individually and may be withdrawn at any time.

---

**Northlatch Labs LLC** — [weir.social](https://weir.social) · [protocolx.io](https://protocolx.io)
