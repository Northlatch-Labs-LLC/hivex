import { useState } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { apiFetch } from '@/lib/api'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { FieldError } from '@/components/ui/field-error'
import { isHttpUrl } from '@/lib/validate'
import { useI18n } from '@/i18n'
import { toast } from '@/lib/toast'
import { DiscoverModelsDialog } from './discover-models-dialog'

// Split a free-text model field on commas / newlines into a clean id list,
// dropping blanks and duplicates so one endpoint can take several models. (#281)
function parseModelList(raw: string): string[] {
  const seen = new Set<string>()
  return raw
    .split(/[\n,]+/)
    .map(s => s.trim())
    .filter(s => s.length > 0 && !seen.has(s) && seen.add(s))
}

// Always rendered inside the Add key dialog: no outer section chrome/heading.
// `onAdded` lets that dialog close (and surface a toast) once a custom model is
// saved. Custom endpoints serve chat models only.
export function CustomProviderSection({ onAdded }: { onAdded?: () => void } = {}) {
  const { t } = useI18n()
  const queryClient = useQueryClient()
  const [baseUrl, setBaseUrl] = useState('')
  const [model, setModel] = useState('')
  const [displayName, setDisplayName] = useState('')
  const [apiKey, setApiKey] = useState('')
  // Chat models default tools on (modern OpenAI-compatible servers all emit tool
  // calls) and vision off; declare them here or flip them later per model. (#470)
  const [supportsTools, setSupportsTools] = useState(true)
  const [supportsVision, setSupportsVision] = useState(false)
  // "Fetch models" asks the endpoint itself what it serves instead of making the
  // user paste ids from a curl (#488).
  const [discoverOpen, setDiscoverOpen] = useState(false)

  const models = parseModelList(model)
  const multiple = models.length > 1

  // Field-level validation: submit stays clickable and reveals what is
  // missing instead of being silently disabled.
  const [attempted, setAttempted] = useState(false)
  const baseUrlError = !baseUrl.trim()
    ? t('validation.required')
    : !isHttpUrl(baseUrl)
      ? t('validation.url')
      : null
  const modelError = models.length === 0 ? t('validation.required') : null

  const addCustom = useMutation({
    meta: { silenceToast: true },
    mutationFn: (body: Record<string, unknown>) =>
      apiFetch('/api/keys/custom', { method: 'POST', body: JSON.stringify(body) }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['keys'] })
      queryClient.invalidateQueries({ queryKey: ['health'] })
      queryClient.invalidateQueries({ queryKey: ['fallback'] })
      queryClient.invalidateQueries({ queryKey: ['models'] })
      setModel('')
      setDisplayName('')
      setSupportsTools(true)
      setSupportsVision(false)
      if (onAdded) {
        toast.success(t('keys.modelAdded'))
        onAdded()
      }
    },
  })

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    if (baseUrlError || modelError) {
      setAttempted(true)
      return
    }
    setAttempted(false)
    addCustom.mutate({
      baseUrl,
      models,
      displayName: !multiple ? (displayName || undefined) : undefined,
      apiKey: apiKey || undefined,
      supportsTools,
      supportsVision,
    })
  }

  const addLabel = multiple ? t('keys.addModels', { count: models.length }) : t('keys.addModel')

  const form = (
      <form onSubmit={submit} className="flex flex-wrap items-end gap-3">
        <div className="space-y-1.5 flex-1 min-w-[240px]">
          <Label className="text-xs">{t('keys.customBaseUrl')}</Label>
          <Input
            value={baseUrl}
            onChange={e => setBaseUrl(e.target.value)}
            placeholder="http://127.0.0.1:11434/v1"
            className="font-mono text-xs"
            aria-invalid={attempted && !!baseUrlError}
          />
          {attempted && <FieldError error={baseUrlError} />}
        </div>
        <div className="space-y-1.5">
          <div className="flex items-center justify-between gap-2">
            <Label className="text-xs">{t('keys.customModels')}</Label>
            <button
              type="button"
              onClick={() => setDiscoverOpen(true)}
              disabled={!!baseUrlError}
              className="text-[11px] text-muted-foreground underline-offset-2 hover:text-foreground hover:underline disabled:pointer-events-none disabled:opacity-50"
            >
              {t('keys.discoverModels')}
            </button>
          </div>
          <Textarea
            value={model}
            onChange={e => setModel(e.target.value)}
            placeholder={'qwen3:4b\nllama3:8b'}
            rows={2}
            className="w-[200px] font-mono text-xs"
            aria-invalid={attempted && !!modelError}
          />
          {attempted && <FieldError error={modelError} />}
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs">{t('keys.customDisplayName')}</Label>
          <Input
            value={displayName}
            onChange={e => setDisplayName(e.target.value)}
            placeholder={multiple ? t('keys.customDisplayNamePerModel') : t('keys.customDisplayNameOptional')}
            disabled={multiple}
            className="w-[150px]"
          />
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs">{t('keys.customCapabilities')}</Label>
          <div className="flex h-9 items-center gap-4">
            <label className="flex items-center gap-1.5 text-xs">
              <Switch size="sm" checked={supportsTools} onCheckedChange={setSupportsTools} />
              <span>{t('models.tools')}</span>
            </label>
            <label className="flex items-center gap-1.5 text-xs">
              <Switch size="sm" checked={supportsVision} onCheckedChange={setSupportsVision} />
              <span>{t('models.vision')}</span>
            </label>
          </div>
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs">{t('keys.customApiKey')}</Label>
          <Input
            type="password"
            value={apiKey}
            onChange={e => setApiKey(e.target.value)}
            placeholder={t('keys.customDisplayNameOptional')}
            className="w-[150px] font-mono text-xs"
          />
        </div>
        <Button type="submit" size="sm" disabled={addCustom.isPending}>
          {addCustom.isPending ? t('keys.addingCustom') : addLabel}
        </Button>
      </form>
  )

  const errorLine = addCustom.isError ? (
    <p className="text-destructive text-xs mt-2">{(addCustom.error as Error).message}</p>
  ) : null

  return (
    <div>
      <p className="text-xs text-muted-foreground mb-3">{t('keys.addCustomDescription')}</p>
      {form}
      {errorLine}
      {discoverOpen && (
        <DiscoverModelsDialog
          open={discoverOpen}
          onOpenChange={setDiscoverOpen}
          endpoint={{ baseUrl, apiKey: apiKey || undefined }}
          onRegistered={onAdded}
        />
      )}
    </div>
  )
}
