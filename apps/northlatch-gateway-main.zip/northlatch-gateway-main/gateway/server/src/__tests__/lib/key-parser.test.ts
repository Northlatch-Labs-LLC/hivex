import { describe, expect, it } from 'vitest';
import {
  AUTH_JSON_PROVIDER_MAP,
  detectPlatform,
  looksLikeApiKey,
  parseAuthJson,
  parseCsv,
  parseDotEnv,
  parseExportJson,
  parseJson,
  parseKeysFromFile,
  stripJsoncComments,
  stripTrailingCommas,
} from '../../lib/key-parser.js';

describe('key parser', () => {
  it('parses dotenv key/value files', () => {
    expect(parseDotEnv('GOOGLE_API_KEY="ai-test"\nGROQ_API_KEY=gsk-test # comment')).toEqual([
      { key: 'GOOGLE_API_KEY', value: 'ai-test' },
      { key: 'GROQ_API_KEY', value: 'gsk-test' },
    ]);
  });

  it('unquotes dotenv values that carry an inline comment', () => {
    expect(parseDotEnv('GOOGLE_API_KEY="ai-test" # primary\nGROQ_API_KEY=\'gsk-test\'  # backup')).toEqual([
      { key: 'GOOGLE_API_KEY', value: 'ai-test' },
      { key: 'GROQ_API_KEY', value: 'gsk-test' },
    ]);
  });

  it('keeps a # that is inside the quotes', () => {
    expect(parseDotEnv('NVIDIA_API_KEY="nv # test"')).toEqual([
      { key: 'NVIDIA_API_KEY', value: 'nv # test' },
    ]);
  });

  it('parses flat JSON string values', () => {
    expect(parseJson(JSON.stringify({ MISTRAL_API_KEY: 'mist-test', PORT: 3001 }))).toEqual([
      { key: 'MISTRAL_API_KEY', value: 'mist-test' },
    ]);
  });

  it('strips JSONC comments and trailing commas', () => {
    const jsonc = '{\n // comment\n "GROQ_API_KEY": "gsk-test",\n}';
    expect(JSON.parse(stripTrailingCommas(stripJsoncComments(jsonc)))).toEqual({
      GROQ_API_KEY: 'gsk-test',
    });
  });

  it('detects current provider prefixes', () => {
    expect(detectPlatform('GOOGLE_')).toBe('google');
    expect(detectPlatform('OLLAMA_CLOUD_')).toBe('ollama');
    expect(detectPlatform('NARAROUTER_')).toBe('nara');
    expect(detectPlatform('AIONLABS_')).toBe('aion');
    expect(detectPlatform('REQUESTY_')).toBe('requesty');
    expect(detectPlatform('NAVYAI_')).toBe('navy');
    expect(detectPlatform('SEALION_')).toBe('sealion');
    expect(detectPlatform('ORCAROUTER_')).toBe('orcarouter');
    expect(detectPlatform('ORCA_')).toBe('orcarouter');
    expect(detectPlatform('UNOROUTER_')).toBe('unorouter');
    expect(detectPlatform('UNO_ROUTER_')).toBe('unorouter');
    expect(detectPlatform('XKIRO_')).toBe('xkiro');
    expect(detectPlatform('MODELSCOPE_')).toBe('modelscope');
    expect(detectPlatform('ANYAPI_')).toBe('anyapi');
    expect(detectPlatform('ANY_API_')).toBe('anyapi');
    expect(detectPlatform('BAI_')).toBe('bai');
    expect(detectPlatform('B_AI_')).toBe('bai');
    expect(detectPlatform('RADEON_')).toBe('radeon');
    expect(detectPlatform('AMD_RADEON_')).toBe('radeon');
    expect(detectPlatform('AMD_TOKENFACTORY_')).toBe('radeon');
    expect(detectPlatform('SAIL_')).toBe('sail');
    expect(detectPlatform('SAIL_RESEARCH_')).toBe('sail');
    expect(detectPlatform('ELECTRONHUB_')).toBe('electronhub');
    expect(detectPlatform('ELECTRON_HUB_')).toBe('electronhub');
    expect(detectPlatform('EXPERIENTIAL_')).toBe('experiential');
    expect(detectPlatform('EXPERIENTIALLABS_')).toBe('experiential');
    expect(detectPlatform('EXPERIENTIAL_LABS_')).toBe('experiential');
    expect(detectPlatform('EXPLABS_')).toBe('experiential');
    expect(detectPlatform('SAMBANOVA_')).toBeNull();
  });

  it('parses Hermes/OpenCode auth.json provider names', () => {
    expect(AUTH_JSON_PROVIDER_MAP['ollama-cloud']).toBe('ollama');
    expect(AUTH_JSON_PROVIDER_MAP['bynara']).toBe('nara');
    expect(AUTH_JSON_PROVIDER_MAP['aion-labs']).toBe('aion');
    expect(AUTH_JSON_PROVIDER_MAP['requesty']).toBe('requesty');
    expect(AUTH_JSON_PROVIDER_MAP['api-navy']).toBe('navy');
    expect(AUTH_JSON_PROVIDER_MAP['sea-lion']).toBe('sealion');
    expect(AUTH_JSON_PROVIDER_MAP['orca-router']).toBe('orcarouter');
    expect(AUTH_JSON_PROVIDER_MAP['uno-router']).toBe('unorouter');
    expect(AUTH_JSON_PROVIDER_MAP['model-scope']).toBe('modelscope');
    expect(AUTH_JSON_PROVIDER_MAP['any-api']).toBe('anyapi');
    expect(AUTH_JSON_PROVIDER_MAP['b-ai']).toBe('bai');
    expect(AUTH_JSON_PROVIDER_MAP['radeon-cloud']).toBe('radeon');
    expect(AUTH_JSON_PROVIDER_MAP['amd-tokenfactory']).toBe('radeon');
    expect(AUTH_JSON_PROVIDER_MAP['sail-research']).toBe('sail');
    expect(AUTH_JSON_PROVIDER_MAP['electron-hub']).toBe('electronhub');
    expect(AUTH_JSON_PROVIDER_MAP['experiential-labs']).toBe('experiential');
    expect(AUTH_JSON_PROVIDER_MAP['explabs']).toBe('experiential');
    const result = parseAuthJson(JSON.stringify({
      credential_pool: {
        gemini: [{ id: '1', label: 'Gemini', auth_type: 'api_key', access_token: 'AIza-test' }],
        github: [{ id: '2', label: 'GitHub', auth_type: 'oauth', access_token: 'gho-test' }],
      },
    }));
    expect(result.keys).toEqual([
      { rawKey: 'Gemini=AIza-test', prefix: 'GOOGLE_', platform: 'google' },
    ]);
    expect(result.skipped[0]).toContain('auth_type is oauth');
  });

  it('keeps unknown but key-like values for preview', () => {
    const result = parseKeysFromFile('ANTHROPIC_API_KEY=sk-ant-test-value\nPORT=3001', 'keys.env');
    expect(result.keys).toEqual([
      { rawKey: 'ANTHROPIC_API_KEY=sk-ant-test-value', prefix: 'ANTHROPIC_', platform: null },
    ]);
    expect(result.skipped).toEqual(['PORT: value does not look like an API key']);
  });

  it('filters obvious non-key values', () => {
    expect(looksLikeApiKey('true')).toBe(false);
    expect(looksLikeApiKey('https://example.com')).toBe(false);
    expect(looksLikeApiKey('sk-valid-token')).toBe(true);
  });

  it('parses Xlaunch Gateway export JSON format', () => {
    const exportJson = JSON.stringify({
      version: 1,
      exportedAt: '2026-07-06T12:00:00Z',
      source: 'xlaunch-gateway',
      keys: [
        { platform: 'google', key: 'AIza-test-key', label: 'Google Key' },
        { platform: 'groq', key: 'gsk-test-key', label: 'Groq Key' },
      ],
    });
    const result = parseExportJson(exportJson);
    expect(result).not.toBeNull();
    expect(result!.keys).toHaveLength(2);
    expect(result!.keys[0]).toEqual({ rawKey: 'Google Key=AIza-test-key', prefix: 'GOOGLE_', platform: 'google' });
    expect(result!.keys[1]).toEqual({ rawKey: 'Groq Key=gsk-test-key', prefix: 'GROQ_', platform: 'groq' });
    expect(result!.skipped).toHaveLength(0);
  });

  it('returns null for non-export JSON', () => {
    expect(parseExportJson('{"foo":"bar"}')).toBeNull();
    expect(parseExportJson('[1,2,3]')).toBeNull();
    expect(parseExportJson('not json')).toBeNull();
  });

  // The platform now rides along explicitly instead of being re-derived from
  // the generated prefix: 'custom' has no PREFIX_MAP entry, so inference alone
  // silently dropped every custom endpoint on import (#687).
  it('parses CSV format with header', () => {
    const csv = 'platform,key,label\n"google","AIza-test","Google Key"\n"groq","gsk-test","Groq Key"\n';
    expect(parseCsv(csv)).toEqual([
      { key: 'GOOGLE_KEY', value: 'AIza-test', platform: 'google' },
      { key: 'GROQ_KEY', value: 'gsk-test', platform: 'groq' },
    ]);
  });

  it('parses CSV format without header', () => {
    const csv = 'google,AIza-test,Google Key\n';
    expect(parseCsv(csv)).toEqual([
      { key: 'GOOGLE_KEY', value: 'AIza-test', platform: 'google' },
    ]);
  });

  it('parses the base_url column that makes a custom row importable', () => {
    const csv = 'platform,key,label,base_url\n"custom","sk-local","LM Studio","http://192.168.1.5:1234/v1"\n';
    expect(parseCsv(csv)).toEqual([
      { key: 'CUSTOM_KEY', value: 'sk-local', platform: 'custom', baseUrl: 'http://192.168.1.5:1234/v1' },
    ]);
  });

  it('handles export JSON via parseKeysFromFile', () => {
    const exportJson = JSON.stringify({
      version: 1,
      exportedAt: '2026-07-06T12:00:00Z',
      source: 'xlaunch-gateway',
      keys: [
        { platform: 'mistral', key: 'mist-test', label: 'Mistral Key' },
      ],
    });
    const result = parseKeysFromFile(exportJson, 'xlaunch-gateway-keys.json');
    expect(result.keys).toHaveLength(1);
    expect(result.keys[0]).toEqual({ rawKey: 'Mistral Key=mist-test', prefix: 'MISTRAL_', platform: 'mistral' });
  });

  it('handles CSV via parseKeysFromFile', () => {
    const csv = 'platform,key,label\n"nvidia","nv-test","Nvidia Key"\n';
    const result = parseKeysFromFile(csv, 'xlaunch-gateway-keys.csv');
    expect(result.keys).toHaveLength(1);
    expect(result.keys[0]).toEqual({ rawKey: 'NVIDIA_KEY=nv-test', prefix: 'NVIDIA_', platform: 'nvidia' });
  });
});
