// Built to build/preload.cjs (CommonJS — the reliable preload format).
// Runs in the renderer before any page script: seeds the dashboard session
// token into localStorage so AuthGate's very first /api/auth/status call is
// authenticated. The token arrives via additionalArguments (process.argv),
// which avoids templating strings into executeJavaScript.
import { contextBridge, ipcRenderer } from 'electron';

const TOKEN_KEY = 'xlaunch_gateway_dashboard_token';
const arg = process.argv.find((a) => a.startsWith('--xlaunch-gateway-token='));
if (arg) {
  try {
    window.localStorage.setItem(TOKEN_KEY, arg.slice('--xlaunch-gateway-token='.length));
  } catch {
    // localStorage unavailable — the dashboard will show its login screen.
  }
}

// Lets the client adapt its chrome (drag region, traffic-light padding,
// no Sign out) when running inside the desktop shell.
contextBridge.exposeInMainWorld('__XLAUNCH_GATEWAY_DESKTOP__', true);

// The dashboard window signs in as the hidden machine account, whose password
// is random and never shown, so it must never land on the login form. When the
// seeded session is gone (expired after 30 days of uptime, or cleared by a 401)
// AuthGate asks the main process for a fresh one instead. Exposed as a bare
// function rather than a broader bridge: the renderer loads http://127.0.0.1,
// and every extra capability handed to that world is one an XSS could use —
// this one only ever hands back a session for the account the window already
// runs as.
contextBridge.exposeInMainWorld('__XLAUNCH_GATEWAY_SESSION__', () => ipcRenderer.invoke('xlaunch-gateway:session-token'));

// `desktop` class on <html> activates the client's translucent backdrop
// (html.desktop in index.css). CAREFUL: for an http:// load the preload
// runs before the page's document is parsed — documentElement is null or
// a placeholder that the parser replaces — so the early add is best-effort
// (no-flash when it sticks) and MUST NOT throw, or the theme observer
// below would never register. The client re-adds the class itself at
// module load (App.tsx), so the effect never depends on the early add.
function applyDesktopClass() {
  document.documentElement?.classList.add('desktop');
}
try {
  applyDesktopClass();
} catch {
  // Document not ready — DOMContentLoaded below covers it.
}

// Mirror the dashboard's theme to the main process so the tray popover
// matches. The dashboard expresses its resolved theme as the `dark` class
// and the underlying choice (dark/light/system) as `data-theme-choice`,
// both on documentElement — observe those rather than reaching across
// worlds into localStorage. The choice lets the main process hand
// nativeTheme.themeSource back to the OS when the user picks System.
function reportTheme() {
  ipcRenderer.send('xlaunch-gateway:theme-changed', {
    resolved: document.documentElement.classList.contains('dark') ? 'dark' : 'light',
    choice: document.documentElement.dataset.themeChoice,
  });
}

// Mirror the dashboard's locale to the main process so the native tray menu and
// the popover match. The I18nProvider sets `<html lang>` on every locale change,
// so observe that attribute rather than reaching into the dashboard's
// localStorage from this preload world.
function reportLocale() {
  const lang = document.documentElement.lang;
  if (lang) ipcRenderer.send('xlaunch-gateway:locale-changed', lang);
}
window.addEventListener('DOMContentLoaded', () => {
  applyDesktopClass();
  reportTheme();
  reportLocale();
  new MutationObserver(() => {
    reportTheme();
    reportLocale();
  }).observe(document.documentElement, {
    attributes: true,
    attributeFilter: ['class', 'lang', 'data-theme-choice'],
  });
});
