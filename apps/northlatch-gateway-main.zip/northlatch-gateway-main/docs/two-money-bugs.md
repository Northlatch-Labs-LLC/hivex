# The payment watcher, and the day it lost a payment

Both of these were found and fixed while the application source was still not under version
control — it lived on one workstation, at `~/Desktop/claudeexp/xlaunch/gateway`, with no history and
no copy anywhere. That is why these two write-ups were committed as loose patches first: the changes
move customers' money and had no record at all. The whole tree is now in `gateway/`, so the next fix
is a diff rather than a description.

## What happened

On 9 September 2026 a customer sent **1 SUI** to the treasury from a wallet registered to their
account. It settled on mainnet. The portal showed them nothing — no balance, no pending payment, no
error. The `payments` table held no row at all, not even the `unmatched` row the module promises for
money that arrives from a wallet nobody has claimed.

Two faults, and the second made the first permanent.

**The coin type never matched.** The scan asked for the treasury's own positive change in SUI:

```ts
&& change.coinType?.repr === '0x2::sui::SUI'
```

The chain does not answer that. It answers the fully expanded form:

```
0x0000000000000000000000000000000000000000000000000000000000000002::sui::SUI
```

Both spell one coin type; neither string equals the other. So the `find` returned nothing on every
transfer that ever arrived, the loop skipped the node, and `recordTransfer` was never reached.

**The cursor stepped over it anyway.** The page cursor advanced whenever the GraphQL query itself
returned:

```ts
const cursor = result.transactions?.pageInfo?.endCursor;
if (cursor) setSetting(KEYS.suiCursor, cursor);
```

The comment above it said it advanced "only after a clean pass". It treated an exception as the only
kind of failure, so a page every node of which was silently discarded counted as clean. The
transaction went behind the cursor, and no later poll could reach it: querying with the stored cursor
returned zero nodes while querying without it returned the payment.

## What changed

- **Canonical forms, everywhere.** `normalizeSuiAddress` pads a Sui address to its full 32 bytes and
  `normalizeCoinType` canonicalizes the package address in front of a type, so which spelling a
  chain, a customer or an operator used cannot decide whether money is seen.
- **A cursor that cannot page over money.** Each node is now examined for *any* positive arrival at
  the treasury, in any coin. A transaction that moved nothing to the treasury is still skipped — it
  merely touched the address. But an arrival this watcher cannot attribute logs and holds the
  cursor, so it stays in view until it is credited or explained.
- **Registration stores what the watcher compares.** `POST /customer-api/wallets` canonicalizes a
  Sui address before storing it, so a customer pasting the short form cannot register a wallet that
  silently matches nothing.

## The tests

`payment-watcher-sui.test.ts` is built from the real transaction —
`ETMWrDN6v4mk8fbqsy2W8YLHMS4TqxbsCNaBgEPwEdZv`, its real digest, addresses, amounts and coin type as
mainnet returned them. Both faults were reintroduced afterwards and the suite re-run to confirm the
tests actually catch them: four of the six fail against the original code.

## Deploying this

The cursor is stored state, so correcting the code is not enough on its own — a payment already
behind the cursor stays there. Clear it once, then deploy:

```
docker exec <container> node -e '…DELETE FROM settings WHERE key = "payments_sui_cursor"…'
cd /srv/gateway && docker compose up -d --force-recreate
```

`docker restart` reuses the container's existing image and deploys nothing. The watcher's first tick
is ten seconds after boot and every sixty thereafter.

## Still open

`billing_sui_usd_rate` is `1`. A customer paying 1 SUI is credited one dollar. That is a setting, not
a fault in this code, and it is the operator's to price.

---

# The rate that could not be a fraction

Two days after the watcher lost a payment, the operator could not price SUI. The field took `1` or
`0` and nothing between, and SUI trades at $0.81.

## What happened

Both rate boxes in the billing settings were controlled inputs whose displayed value was recomputed
from the number on every keystroke:

```tsx
value={String(value.suiUsdRate)}
onChange={(e) => setDraft({ ...draft, suiUsdRate: Number(e.target.value) || 0 })}
```

Type `3`, and the box shows `3`. Type `.`, and `Number("3.")` is `3`, which renders as `3` — the
decimal point was deleted at the instant it was typed. No fractional rate could be entered at all.
The server had never been the problem: its schema is `z.number()`, and it would have accepted `0.81`
any day.

The `|| 0` was the quieter half. Clearing the box gave `Number("")` → `0` → falsy → `0`, so an
operator who selected-all before retyping had, for that keystroke, set the rate to zero — and
`usdMicrosFor` treats a zero rate as *record the payment, credit nothing*. A cleared text box could
have turned every subsequent SUI payment into a free deposit.

## What changed

The two rates are now held as the operator's own text while they are being typed, and parsed only
when what is in the box is actually a number. An empty or half-typed entry (`""`, `"3."`) leaves the
stored rate untouched rather than resetting it to zero. Saving and cancelling both return the boxes
to the server's numbers.

Text is what a person types; the number is what is saved. They are not the same thing, and a
half-typed number is not a number yet.

## Confirmed by use

The operator set `billing_sui_usd_rate = 0.67` within minutes of the deploy — a value that could not
have been entered before it.

## Still open

The SUI rate is static. Nothing updates it, so it drifts as the market moves and every payment is
credited at whatever was last typed. A payment already credited keeps the rate it was credited at:
the 1 SUI credited at `1` stays $1.00 although it was worth about $0.81.
